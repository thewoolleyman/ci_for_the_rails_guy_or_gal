/**********************************************************************
Copyright 2004, Bulent Yilmaz
for Microbrew Software

Part of Microbrew md5sum/sha1sum
GNU textutils md5sum replacement

http://www.microbrew.org/tools/md5sha1sum.html

Microbrew md5sum/sha1sum is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

MicroSieve is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with MicroSieve; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

**********************************************************************/

#define REL_VERSION "0.9.5"
#define REL_DATE "Wed Dec  6 12:48:56 EST 2006"
